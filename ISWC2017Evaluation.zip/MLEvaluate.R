##########################   LOAD EVAL DATA  ###################
#Initialise
file = '/home/asha/datafiles/MLEvaluation/EvalSheets/RML_apy_100.csv-EvaluateScheme.csv'  
temp1 <- read.csv(file,header=TRUE,sep=",",stringsAsFactors=F)
wMLUserEvalScheme <- temp1[0,]
#List File in the directory to be uploaded
L1 <- list.files(path = "/home/asha/datafiles/MLEvaluation/EvalSheets", pattern = "RML_", all.files = FALSE, full.names = FALSE, recursive = FALSE,ignore.case = FALSE, include.dirs = FALSE, no.. = FALSE)
# Load and append to global dataframeL
for (file in L1[1:60]){
  file = paste("/home/asha/datafiles/MLEvaluation/EvalSheets/",file,sep="",collapse = NULL)
  print(file)
  temp <- read.csv(file,header=TRUE,sep=",",stringsAsFactors=F)
  wMLUserEvalScheme <- rbind(wMLUserEvalScheme,temp)
}
##########################   Summarise  with ML Data ###################
nrows = nrow(wMLUserEvalScheme)
nLV = nrow(wMLUserEvalScheme[which(wMLUserEvalScheme[,8] == 1),])
LV = wMLUserEvalScheme[which(wMLUserEvalScheme[,8] == 1),]
LVML = wMLUserEvalScheme[which(wMLUserEvalScheme[,8] == 1),]
percentLV = nLV/nrows
nNoProp = nrow(LV[which(LV[,5] == LV[,6]),])
nWithProp = nrow(LV[which(LV[,5] != LV[,6]),])
WithProp = LV[which(LV[,5] != LV[,6]),]
percentNoProp = nNoProp/nLV
percentWithProp = nWithProp/nLV
nWithCorrProp = nrow(WithProp[which(WithProp[,9] == 1),])
nWithInCorrProp = nrow(WithProp[which(WithProp[,9] == 0),])
WithInCorrProp = WithProp[which(WithProp[,9] == 0),]
percentWithCorrProp = nWithCorrProp/nWithProp
SummarywML <- data.frame("%LV"=percentLV,"%NoProp"=percentNoProp,"%WithProp"=percentWithProp,"%WithCorrectProp"=percentWithCorrProp)
##########################   LOAD EVAL DATA  ###################
#Initialise
file = '/home/asha/datafiles/JOWSEvaluation/EvaluationSheets/RNonML_apy_100.csv-EvaluateScheme.csv'  
temp2 <- read.csv(file,header=TRUE,sep=",",stringsAsFactors=F)
woMLUserEvalScheme <- temp2[0,]
#List File in the directory to be uploaded
L2 <- list.files(path = "/home/asha/datafiles/JOWSEvaluation/EvaluationSheets", pattern = "RNonML_", all.files = FALSE, full.names = FALSE, recursive = FALSE,ignore.case = FALSE, include.dirs = FALSE, no.. = FALSE)
# Load and append to global dataframe
for (file in L2[1:60]){
  file = paste("/home/asha/datafiles/JOWSEvaluation/EvaluationSheets/",file,sep="",collapse = NULL)
  print(file)
  temp <- read.csv(file,header=TRUE,sep=",",stringsAsFactors=F)
  woMLUserEvalScheme <- rbind(woMLUserEvalScheme,temp)
}
##########################   Summarise  with NON ML Data ###################
nrows = nrow(woMLUserEvalScheme)
nLV = nrow(woMLUserEvalScheme[which(woMLUserEvalScheme[,8] == 1),])
LV = woMLUserEvalScheme[which(woMLUserEvalScheme[,8] == 1),]
LVNonML = woMLUserEvalScheme[which(woMLUserEvalScheme[,8] == 1),]
percentLV = nLV/nrows
nNoProp = nrow(LV[which(LV[,5] == LV[,6]),])
nWithProp = nrow(LV[which(LV[,5] != LV[,6]),])
WithProp = LV[which(LV[,5] != LV[,6]),]
percentNoProp = nNoProp/nLV
percentWithProp = nWithProp/nLV
SummarywoML <- data.frame("%LV"=percentLV,"%NoProp"=percentNoProp,"%WithProp"=percentWithProp)

##########################   View Summarisations ###################
SummarywoML
SummarywML
